from setuptools import setup, find_packages


setup(
    name='traingle_kejebi',
    version='0.1',
    license='MIT',
    author="Ketevan Jebisashvili",
    author_email='kejebi@ttu.ee',
    packages=find_packages('src'),
    package_dir={'': 'src'},
    keywords='traingle area project',
    

)
