def area_calculator(b, h): 
 result = 0.5 * b * h 
 return result
 